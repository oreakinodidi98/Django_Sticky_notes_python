from django.contrib import admin
# import models 
from .models import Stick_notes, Author

# Register sticky_notes model
admin.site.register(Stick_notes)
# Register Author model
admin.site.register(Author)
