import setuptools

setuptools.setup(
    install_requires=[
        "sticky_notes==0.0.1",
    ]
)